package com.todoapp.backend.model;

import jakarta.persistence.*;
import lombok.Data;
import java.util.List;

@Entity
@Table(name = "priorities")
@Data
public class Priority {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(unique = true, nullable = false)
    private String level; // HIGH, MEDIUM, LOW
    
    @Column(nullable = false)
    private Integer priorityValue; // CHANGED FROM 'value' TO 'priorityValue'
    
    private String colorCode;
    
    @OneToMany(mappedBy = "priority")
    private List<Todo> todos;
}