package com.todoapp.backend.controller;

import com.todoapp.backend.dto.TodoRequest;
import com.todoapp.backend.dto.TodoResponse;
import com.todoapp.backend.service.TodoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/todos")
@CrossOrigin(origins = "*")
public class TodoController {
    
    @Autowired
    private TodoService todoService;
    
    // Get all todos for a user
    @GetMapping("/user/{userId}")
    public ResponseEntity<?> getUserTodos(@PathVariable Long userId) {
        try {
            List<TodoResponse> todos = todoService.getUserTodos(userId);
            return ResponseEntity.ok(todos);
        } catch (Exception e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // Get todos by status (completed/pending)
    @GetMapping("/user/{userId}/status")
    public ResponseEntity<?> getUserTodosByStatus(
            @PathVariable Long userId,
            @RequestParam Boolean completed) {
        try {
            List<TodoResponse> todos = todoService.getUserTodosByStatus(userId, completed);
            return ResponseEntity.ok(todos);
        } catch (Exception e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // Get todos by priority
    @GetMapping("/user/{userId}/priority/{priorityId}")
    public ResponseEntity<?> getUserTodosByPriority(
            @PathVariable Long userId,
            @PathVariable Long priorityId) {
        try {
            List<TodoResponse> todos = todoService.getUserTodosByPriority(userId, priorityId);
            return ResponseEntity.ok(todos);
        } catch (Exception e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // Get todos due between dates
    @GetMapping("/user/{userId}/due")
    public ResponseEntity<?> getUserTodosDueBetween(
            @PathVariable Long userId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate start,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate end) {
        try {
            List<TodoResponse> todos = todoService.getUserTodosDueBetween(userId, start, end);
            return ResponseEntity.ok(todos);
        } catch (Exception e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // Create new todo
    @PostMapping("/user/{userId}")
    public ResponseEntity<?> createTodo(
            @PathVariable Long userId,
            @RequestBody TodoRequest request) {
        try {
            TodoResponse todo = todoService.createTodo(userId, request);
            return ResponseEntity.ok(todo);
        } catch (Exception e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // Update todo
    @PutMapping("/{todoId}")
    public ResponseEntity<?> updateTodo(
            @PathVariable Long todoId,
            @RequestBody TodoRequest request) {
        try {
            TodoResponse todo = todoService.updateTodo(todoId, request);
            return ResponseEntity.ok(todo);
        } catch (Exception e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // Toggle todo status (complete/pending)
    @PatchMapping("/{todoId}/toggle")
    public ResponseEntity<?> toggleTodoStatus(@PathVariable Long todoId) {
        try {
            TodoResponse todo = todoService.toggleTodoStatus(todoId);
            return ResponseEntity.ok(todo);
        } catch (Exception e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // Delete todo
    @DeleteMapping("/{todoId}")
    public ResponseEntity<?> deleteTodo(@PathVariable Long todoId) {
        try {
            todoService.deleteTodo(todoId);
            Map<String, String> response = new HashMap<>();
            response.put("message", "Todo deleted successfully!");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
}