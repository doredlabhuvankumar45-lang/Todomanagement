package com.todoapp.backend.service;

import com.todoapp.backend.dto.TodoRequest;
import com.todoapp.backend.dto.TodoResponse;
import com.todoapp.backend.model.*;
import com.todoapp.backend.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class TodoService {
    
    @Autowired
    private TodoRepository todoRepository;
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private CategoryRepository categoryRepository;
    
    @Autowired
    private PriorityRepository priorityRepository;
    
    public TodoResponse createTodo(Long userId, TodoRequest request) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found!"));
        
        Priority priority = priorityRepository.findById(request.getPriorityId())
                .orElseThrow(() -> new RuntimeException("Priority not found!"));
        
        Todo todo = new Todo();
        todo.setTitle(request.getTitle());
        todo.setDescription(request.getDescription());
        todo.setDueDate(request.getDueDate());
        todo.setUser(user);
        todo.setPriority(priority);
        todo.setCompleted(false);
        
        if (request.getCategoryId() != null) {
            Category category = categoryRepository.findById(request.getCategoryId())
                    .orElse(null);
            todo.setCategory(category);
        }
        
        Todo savedTodo = todoRepository.save(todo);
        return convertToResponse(savedTodo);
    }
    
    public List<TodoResponse> getUserTodos(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found!"));
        
        return todoRepository.findByUser(user).stream()
                .map(this::convertToResponse)
                .collect(Collectors.toList());
    }
    
    public List<TodoResponse> getUserTodosByStatus(Long userId, Boolean completed) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found!"));
        
        return todoRepository.findByUserAndCompleted(user, completed).stream()
                .map(this::convertToResponse)
                .collect(Collectors.toList());
    }
    
    public List<TodoResponse> getUserTodosByPriority(Long userId, Long priorityId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found!"));
        
        return todoRepository.findByUserAndPriorityId(user, priorityId).stream()
                .map(this::convertToResponse)
                .collect(Collectors.toList());
    }
    
    public List<TodoResponse> getUserTodosDueBetween(Long userId, LocalDate start, LocalDate end) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found!"));
        
        return todoRepository.findTasksDueBetween(user, start, end).stream()
                .map(this::convertToResponse)
                .collect(Collectors.toList());
    }
    
    public TodoResponse updateTodo(Long todoId, TodoRequest request) {
        Todo todo = todoRepository.findById(todoId)
                .orElseThrow(() -> new RuntimeException("Todo not found!"));
        
        todo.setTitle(request.getTitle());
        todo.setDescription(request.getDescription());
        todo.setDueDate(request.getDueDate());
        
        if (request.getCompleted() != null) {
            todo.setCompleted(request.getCompleted());
        }
        
        if (request.getPriorityId() != null) {
            Priority priority = priorityRepository.findById(request.getPriorityId())
                    .orElseThrow(() -> new RuntimeException("Priority not found!"));
            todo.setPriority(priority);
        }
        
        if (request.getCategoryId() != null) {
            Category category = categoryRepository.findById(request.getCategoryId())
                    .orElse(null);
            todo.setCategory(category);
        }
        
        Todo updatedTodo = todoRepository.save(todo);
        return convertToResponse(updatedTodo);
    }
    
    public void deleteTodo(Long todoId) {
        todoRepository.deleteById(todoId);
    }
    
    public TodoResponse toggleTodoStatus(Long todoId) {
        Todo todo = todoRepository.findById(todoId)
                .orElseThrow(() -> new RuntimeException("Todo not found!"));
        
        todo.setCompleted(!todo.getCompleted());
        Todo updatedTodo = todoRepository.save(todo);
        return convertToResponse(updatedTodo);
    }
    
    private TodoResponse convertToResponse(Todo todo) {
        TodoResponse response = new TodoResponse();
        response.setId(todo.getId());
        response.setTitle(todo.getTitle());
        response.setDescription(todo.getDescription());
        response.setDueDate(todo.getDueDate());
        response.setCompleted(todo.getCompleted());
        response.setCreatedAt(todo.getCreatedAt());
        
        if (todo.getCategory() != null) {
            response.setCategoryName(todo.getCategory().getName());
        }
        
        if (todo.getPriority() != null) {
            response.setPriorityLevel(todo.getPriority().getLevel());
        }
        
        return response;
    }
}