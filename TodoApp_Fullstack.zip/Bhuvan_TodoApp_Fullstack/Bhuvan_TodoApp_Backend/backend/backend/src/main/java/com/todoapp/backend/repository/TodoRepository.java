package com.todoapp.backend.repository;

import com.todoapp.backend.model.Todo;
import com.todoapp.backend.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.time.LocalDate;
import java.util.List;

public interface TodoRepository extends JpaRepository<Todo, Long> {
    List<Todo> findByUser(User user);
    List<Todo> findByUserAndCompleted(User user, Boolean completed);
    List<Todo> findByUserAndPriorityId(User user, Long priorityId);
    
    @Query("SELECT t FROM Todo t WHERE t.user = :user AND t.dueDate BETWEEN :start AND :end")
    List<Todo> findTasksDueBetween(@Param("user") User user, 
                                   @Param("start") LocalDate start, 
                                   @Param("end") LocalDate end);
}