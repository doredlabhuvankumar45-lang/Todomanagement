package com.todoapp.backend.repository;

import com.todoapp.backend.model.Category;
import com.todoapp.backend.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface CategoryRepository extends JpaRepository<Category, Long> {
    List<Category> findByUserOrUserIsNull(User user);
}