package com.todoapp.backend.repository;

import com.todoapp.backend.model.Priority;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface PriorityRepository extends JpaRepository<Priority, Long> {
    Optional<Priority> findByLevel(String level);
}