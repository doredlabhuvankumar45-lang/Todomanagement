package com.todoapp.backend.repository;

import com.todoapp.backend.model.TaskHistory;
import com.todoapp.backend.model.Todo;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface TaskHistoryRepository extends JpaRepository<TaskHistory, Long> {
    List<TaskHistory> findByTodo(Todo todo);
}