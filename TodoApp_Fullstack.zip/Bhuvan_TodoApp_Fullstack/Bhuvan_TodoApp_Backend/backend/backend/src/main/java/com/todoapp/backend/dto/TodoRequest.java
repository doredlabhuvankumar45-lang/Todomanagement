package com.todoapp.backend.dto;

import lombok.Data;
import java.time.LocalDate;

@Data
public class TodoRequest {
    private String title;
    private String description;
    private LocalDate dueDate;
    private Long categoryId;
    private Long priorityId;
    private Boolean completed;
}