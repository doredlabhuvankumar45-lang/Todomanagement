package com.todoapp.backend.config;

import com.todoapp.backend.model.*;
import com.todoapp.backend.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDate;

@Component
public class DataInitializer implements CommandLineRunner {
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private PriorityRepository priorityRepository;
    
    @Autowired
    private CategoryRepository categoryRepository;
    
    @Autowired
    private TodoRepository todoRepository;
    
    @Override
    @Transactional
    public void run(String... args) throws Exception {
        System.out.println("=== CHECKING IF SAMPLE DATA NEEDS TO BE CREATED ===");
        
        // Create priorities if they don't exist
        if (priorityRepository.count() == 0) {
            System.out.println("Creating priority data...");
            
            Priority high = new Priority();
            high.setLevel("HIGH");
            high.setPriorityValue(3);
            high.setColorCode("#FF4444");
            priorityRepository.save(high);
            
            Priority medium = new Priority();
            medium.setLevel("MEDIUM");
            medium.setPriorityValue(2);
            medium.setColorCode("#FFBB33");
            priorityRepository.save(medium);
            
            Priority low = new Priority();
            low.setLevel("LOW");
            low.setPriorityValue(1);
            low.setColorCode("#00C851");
            priorityRepository.save(low);
            
            System.out.println("Priority data created successfully!");
        } else {
            System.out.println("Priority data already exists.");
        }
        
        // Create demo user if not exists
        if (!userRepository.existsByUsername("demo")) {
            System.out.println("Creating demo user...");
            
            User demoUser = new User();
            demoUser.setUsername("demo");
            demoUser.setEmail("demo@todo.com");
            demoUser.setPassword("demo123");
            demoUser.setFullName("Demo User");
            userRepository.save(demoUser);
            
            // Get priorities
            Priority high = priorityRepository.findByLevel("HIGH").get();
            Priority medium = priorityRepository.findByLevel("MEDIUM").get();
            Priority low = priorityRepository.findByLevel("LOW").get();
            
            // Create categories
            Category work = new Category();
            work.setName("Work");
            work.setUser(demoUser);
            categoryRepository.save(work);
            
            Category personal = new Category();
            personal.setName("Personal");
            personal.setUser(demoUser);
            categoryRepository.save(personal);
            
            Category shopping = new Category();
            shopping.setName("Shopping");
            shopping.setUser(demoUser);
            categoryRepository.save(shopping);
            
            Category health = new Category();
            health.setName("Health");
            health.setUser(demoUser);
            categoryRepository.save(health);
            
            // Create sample todos
            Todo todo1 = new Todo();
            todo1.setTitle("Complete project report");
            todo1.setDescription("Finish the quarterly project report for client");
            todo1.setDueDate(LocalDate.now().plusDays(3));
            todo1.setUser(demoUser);
            todo1.setPriority(high);
            todo1.setCategory(work);
            todo1.setCompleted(false);
            todoRepository.save(todo1);
            
            Todo todo2 = new Todo();
            todo2.setTitle("Buy groceries");
            todo2.setDescription("Milk, eggs, bread, vegetables");
            todo2.setDueDate(LocalDate.now().plusDays(1));
            todo2.setUser(demoUser);
            todo2.setPriority(medium);
            todo2.setCategory(shopping);
            todo2.setCompleted(false);
            todoRepository.save(todo2);
            
            Todo todo3 = new Todo();
            todo3.setTitle("Team meeting");
            todo3.setDescription("Weekly sync with development team");
            todo3.setDueDate(LocalDate.now().plusDays(2));
            todo3.setUser(demoUser);
            todo3.setPriority(medium);
            todo3.setCategory(work);
            todo3.setCompleted(false);
            todoRepository.save(todo3);
            
            Todo todo4 = new Todo();
            todo4.setTitle("Go to gym");
            todo4.setDescription("Cardio and strength training");
            todo4.setDueDate(LocalDate.now().plusDays(1));
            todo4.setUser(demoUser);
            todo4.setPriority(high);
            todo4.setCategory(health);
            todo4.setCompleted(false);
            todoRepository.save(todo4);
            
            Todo todo5 = new Todo();
            todo5.setTitle("Pay bills");
            todo5.setDescription("Electricity and internet bills");
            todo5.setDueDate(LocalDate.now().plusDays(4));
            todo5.setUser(demoUser);
            todo5.setPriority(medium);
            todo5.setCategory(personal);
            todo5.setCompleted(false);
            todoRepository.save(todo5);
            
            Todo todo6 = new Todo();
            todo6.setTitle("Read book");
            todo6.setDescription("Finish Chapter 5 of Clean Code");
            todo6.setDueDate(LocalDate.now().plusDays(5));
            todo6.setUser(demoUser);
            todo6.setPriority(low);
            todo6.setCategory(personal);
            todo6.setCompleted(false);
            todoRepository.save(todo6);
            
            Todo todo7 = new Todo();
            todo7.setTitle("Call parents");
            todo7.setDueDate(LocalDate.now().minusDays(1));
            todo7.setUser(demoUser);
            todo7.setPriority(medium);
            todo7.setCategory(personal);
            todo7.setCompleted(true);
            todoRepository.save(todo7);
            
            System.out.println("Demo user and sample tasks created successfully!");
        } else {
            System.out.println("Demo user already exists.");
        }
        
        System.out.println("=== DATA INITIALIZATION COMPLETE ===");
    }
}