// ============================================
// GLOBAL VARIABLES
// ============================================
let currentUser = null;
let tasks = [];
let currentView = 'all';

// API BASE URL
const API_BASE_URL = 'http://localhost:8080/api';

// Get user ID from localStorage - YOUR USER ID IS 2
const DEMO_USER_ID = localStorage.getItem('userId') || 2;

// ============================================
// UTILITY FUNCTIONS
// ============================================

// Format date for display
function formatDate(dateString) {
    if (!dateString) return 'No date';
    const options = { year: 'numeric', month: 'short', day: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
}

// Show notification
function showNotification(message, type = 'success') {
    // Remove any existing notification
    const existingNotification = document.querySelector('.notification');
    if (existingNotification) {
        existingNotification.remove();
    }
    
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <i class="fas ${type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'}"></i>
        <span>${message}</span>
    `;
    
    // Add styles if not present
    if (!document.querySelector('#notification-styles')) {
        const style = document.createElement('style');
        style.id = 'notification-styles';
        style.textContent = `
            .notification {
                position: fixed;
                top: 20px;
                right: 20px;
                padding: 15px 25px;
                border-radius: 5px;
                color: white;
                font-weight: 500;
                z-index: 9999;
                animation: slideIn 0.3s ease;
                box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            }
            .notification.success {
                background: #28a745;
            }
            .notification.error {
                background: #dc3545;
            }
            .notification i {
                margin-right: 10px;
            }
            @keyframes slideIn {
                from {
                    transform: translateX(100%);
                    opacity: 0;
                }
                to {
                    transform: translateX(0);
                    opacity: 1;
                }
            }
        `;
        document.head.appendChild(style);
    }
    
    // Add to body
    document.body.appendChild(notification);
    
    // Remove after 3 seconds
    setTimeout(() => {
        if (notification.parentNode) {
            notification.remove();
        }
    }, 3000);
}

// Show loading indicator
function showLoading(show = true) {
    const container = document.getElementById('tasksContainer');
    if (!container) return;
    
    if (show) {
        container.innerHTML = '<div class="loading"><i class="fas fa-spinner fa-spin"></i> Loading tasks...</div>';
    }
}

// ============================================
// API CALLS
// ============================================

// Fetch all tasks for user
async function fetchTasks() {
    showLoading(true);
    try {
        // Get userId from localStorage
        const userId = localStorage.getItem('userId') || 2;
        console.log('Fetching tasks for user ID:', userId);
        
        const response = await fetch(`${API_BASE_URL}/todos/user/${userId}`);
        
        if (!response.ok) {
            throw new Error('Failed to fetch tasks');
        }
        tasks = await response.json();
        console.log('Tasks loaded:', tasks);
        renderTasks();
        updateStats();
    } catch (error) {
        console.error('Error fetching tasks:', error);
        showNotification('Failed to load tasks', 'error');
        tasks = [];
        renderTasks();
    } finally {
        showLoading(false);
    }
}

// Create new task
async function createTask(taskData) {
    try {
        const userId = localStorage.getItem('userId') || 2;
        const response = await fetch(`${API_BASE_URL}/todos/user/${userId}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(taskData)
        });
        
        if (!response.ok) {
            throw new Error('Failed to create task');
        }
        
        const newTask = await response.json();
        tasks.unshift(newTask);
        renderTasks();
        updateStats();
        showNotification('Task created successfully!');
        return newTask;
    } catch (error) {
        console.error('Error creating task:', error);
        showNotification('Failed to create task', 'error');
    }
}

// Update task
async function updateTask(taskId, taskData) {
    try {
        const response = await fetch(`${API_BASE_URL}/todos/${taskId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(taskData)
        });
        
        if (!response.ok) {
            throw new Error('Failed to update task');
        }
        
        const updatedTask = await response.json();
        
        // Update local tasks array
        const index = tasks.findIndex(t => t.id === taskId);
        if (index !== -1) {
            tasks[index] = updatedTask;
        }
        
        renderTasks();
        updateStats();
        showNotification('Task updated successfully!');
    } catch (error) {
        console.error('Error updating task:', error);
        showNotification('Failed to update task', 'error');
    }
}

// Delete task
async function deleteTask(taskId) {
    if (!confirm('Are you sure you want to delete this task?')) return;
    
    try {
        const response = await fetch(`${API_BASE_URL}/todos/${taskId}`, {
            method: 'DELETE'
        });
        
        if (!response.ok) {
            throw new Error('Failed to delete task');
        }
        
        tasks = tasks.filter(t => t.id !== taskId);
        renderTasks();
        updateStats();
        showNotification('Task deleted successfully!');
    } catch (error) {
        console.error('Error deleting task:', error);
        showNotification('Failed to delete task', 'error');
    }
}

// Toggle task completion
async function toggleTaskComplete(taskId) {
    try {
        const response = await fetch(`${API_BASE_URL}/todos/${taskId}/toggle`, {
            method: 'PATCH'
        });
        
        if (!response.ok) {
            throw new Error('Failed to toggle task');
        }
        
        const updatedTask = await response.json();
        
        // Update local tasks array
        const index = tasks.findIndex(t => t.id === taskId);
        if (index !== -1) {
            tasks[index] = updatedTask;
        }
        
        renderTasks();
        updateStats();
        showNotification(updatedTask.completed ? 'Task completed!' : 'Task reopened');
    } catch (error) {
        console.error('Error toggling task:', error);
        showNotification('Failed to update task', 'error');
    }
}

// ============================================
// TASK MANAGEMENT FUNCTIONS
// ============================================

// Filter tasks based on current view
function filterTasks() {
    let filteredTasks = tasks;
    
    switch(currentView) {
        case 'pending':
            filteredTasks = tasks.filter(t => !t.completed);
            break;
        case 'completed':
            filteredTasks = tasks.filter(t => t.completed);
            break;
        case 'high':
            filteredTasks = tasks.filter(t => t.priorityLevel === 'HIGH');
            break;
        case 'medium':
            filteredTasks = tasks.filter(t => t.priorityLevel === 'MEDIUM');
            break;
        case 'low':
            filteredTasks = tasks.filter(t => t.priorityLevel === 'LOW');
            break;
        default:
            filteredTasks = tasks;
    }
    
    // Apply search if search input exists
    const searchInput = document.getElementById('searchTasks');
    if (searchInput && searchInput.value) {
        const searchTerm = searchInput.value.toLowerCase();
        filteredTasks = filteredTasks.filter(t => 
            t.title.toLowerCase().includes(searchTerm) ||
            (t.description && t.description.toLowerCase().includes(searchTerm))
        );
    }
    
    return filteredTasks;
}

// Render tasks to DOM
function renderTasks() {
    const container = document.getElementById('tasksContainer');
    if (!container) return;
    
    const filteredTasks = filterTasks();
    
    if (filteredTasks.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-clipboard-list" style="font-size: 48px; color: #ccc; margin-bottom: 20px;"></i>
                <h3>No tasks found</h3>
                <p>Add a new task to get started!</p>
            </div>
        `;
        return;
    }
    
    let html = '';
    filteredTasks.forEach(task => {
        const priorityClass = `priority-${task.priorityLevel?.toLowerCase() || 'medium'}`;
        const completedClass = task.completed ? 'completed' : '';
        
        html += `
            <div class="task-card ${completedClass}" data-id="${task.id}">
                <div class="task-content">
                    <div class="task-header">
                        <input type="checkbox" class="task-checkbox" ${task.completed ? 'checked' : ''}>
                        <span class="task-title">${task.title}</span>
                        <span class="task-priority ${priorityClass}">${task.priorityLevel || 'MEDIUM'}</span>
                    </div>
                    ${task.description ? `<div class="task-description">${task.description}</div>` : ''}
                    <div class="task-meta">
                        <span><i class="fas fa-calendar"></i> Due: ${formatDate(task.dueDate)}</span>
                        <span><i class="fas fa-tag"></i> ${task.categoryName || 'uncategorized'}</span>
                    </div>
                </div>
                <div class="task-actions">
                    <button class="edit-btn" onclick="editTask(${task.id})">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="delete-btn" onclick="deleteTask(${task.id})">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
        `;
    });
    
    container.innerHTML = html;
    
    // Add event listeners to checkboxes
    document.querySelectorAll('.task-checkbox').forEach(checkbox => {
        checkbox.addEventListener('change', function(e) {
            const taskId = parseInt(this.closest('.task-card').dataset.id);
            toggleTaskComplete(taskId);
        });
    });
}

// Update statistics
function updateStats() {
    const totalTasks = tasks.length;
    const completedTasks = tasks.filter(t => t.completed).length;
    const pendingTasks = totalTasks - completedTasks;
    
    const totalEl = document.getElementById('totalTasks');
    const completedEl = document.getElementById('completedTasks');
    const pendingEl = document.getElementById('pendingTasks');
    
    if (totalEl) totalEl.textContent = totalTasks;
    if (completedEl) completedEl.textContent = completedTasks;
    if (pendingEl) pendingEl.textContent = pendingTasks;
}

// Add new task
async function addTask(event) {
    event.preventDefault();
    
    const title = document.getElementById('taskTitle').value;
    const priority = document.getElementById('taskPriority').value;
    const dueDate = document.getElementById('taskDueDate').value;
    const category = document.getElementById('taskCategory').value;
    const description = document.getElementById('taskDescription').value;
    
    if (!title || !priority || !dueDate) {
        showNotification('Please fill all required fields', 'error');
        return;
    }
    
    // Map priority to priorityId
    const priorityMap = {
        'high': 1,
        'medium': 2,
        'low': 3
    };
    
    const taskData = {
        title,
        description,
        dueDate,
        priorityId: priorityMap[priority],
        completed: false
    };
    
    await createTask(taskData);
    
    // Reset form
    document.getElementById('addTaskForm').reset();
}

// Edit task
async function editTask(taskId) {
    const task = tasks.find(t => t.id === taskId);
    if (!task) return;
    
    // Map priority level to priorityId
    const priorityMap = {
        'HIGH': 1,
        'MEDIUM': 2,
        'LOW': 3
    };
    
    // Fill modal with task data
    document.getElementById('editTaskId').value = task.id;
    document.getElementById('editTitle').value = task.title;
    document.getElementById('editDescription').value = task.description || '';
    document.getElementById('editPriority').value = priorityMap[task.priorityLevel] || 2;
    document.getElementById('editDueDate').value = task.dueDate;
    document.getElementById('editCategory').value = task.categoryName?.toLowerCase() || 'work';
    document.getElementById('editCompleted').checked = task.completed;
    
    // Show modal
    document.getElementById('editModal').classList.add('show');
}

// Save edited task
async function saveEditTask(event) {
    event.preventDefault();
    
    const taskId = parseInt(document.getElementById('editTaskId').value);
    
    const taskData = {
        title: document.getElementById('editTitle').value,
        description: document.getElementById('editDescription').value,
        priorityId: parseInt(document.getElementById('editPriority').value),
        dueDate: document.getElementById('editDueDate').value,
        completed: document.getElementById('editCompleted').checked
    };
    
    await updateTask(taskId, taskData);
    closeModal();
}

// Close modal
function closeModal() {
    const modal = document.getElementById('editModal');
    if (modal) {
        modal.classList.remove('show');
    }
}

// Change view
function changeView(view, element) {
    currentView = view;
    
    // Update active menu item
    document.querySelectorAll('.menu-item').forEach(item => {
        item.classList.remove('active');
    });
    element.classList.add('active');
    
    // Update title
    const titles = {
        all: 'All Tasks',
        pending: 'Pending Tasks',
        completed: 'Completed Tasks',
        high: 'High Priority Tasks',
        medium: 'Medium Priority Tasks',
        low: 'Low Priority Tasks'
    };
    const titleEl = document.getElementById('currentViewTitle');
    if (titleEl) titleEl.textContent = titles[view];
    
    renderTasks();
}

// ============================================
// AUTHENTICATION FUNCTIONS
// ============================================

// Login function
async function handleLogin(event) {
    event.preventDefault();
    
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    
    // Disable login button to prevent multiple clicks
    const loginBtn = event.target.querySelector('button[type="submit"]');
    if (loginBtn) {
        loginBtn.disabled = true;
        loginBtn.textContent = 'Logging in...';
    }
    
    try {
        console.log('Attempting login with:', email);
        
        const response = await fetch(`${API_BASE_URL}/auth/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                usernameOrEmail: email,
                password: password
            })
        });
        
        const data = await response.json();
        console.log('Login response:', data);
        
        if (!response.ok) {
            throw new Error(data.error || 'Login failed');
        }
        
        // Store user data
        localStorage.setItem('isLoggedIn', 'true');
        localStorage.setItem('userName', data.fullName || data.username || 'User');
        localStorage.setItem('userId', data.userId || 2);
        
        showNotification('Login successful! Redirecting...', 'success');
        
        // Redirect after short delay
        setTimeout(() => {
            window.location.href = 'dashboard.html';
        }, 1000);
        
    } catch (error) {
        console.error('Login error:', error);
        showNotification(error.message || 'Invalid email or password', 'error');
        
        // Re-enable login button
        if (loginBtn) {
            loginBtn.disabled = false;
            loginBtn.textContent = 'Login';
        }
    }
}

// Register function
async function handleRegister(event) {
    event.preventDefault();
    
    const firstName = document.getElementById('firstName')?.value || '';
    const lastName = document.getElementById('lastName')?.value || '';
    const username = document.getElementById('username').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    
    if (password !== confirmPassword) {
        showNotification('Passwords do not match', 'error');
        return;
    }
    
    if (password.length < 6) {
        showNotification('Password must be at least 6 characters', 'error');
        return;
    }
    
    // Disable register button
    const registerBtn = event.target.querySelector('button[type="submit"]');
    if (registerBtn) {
        registerBtn.disabled = true;
        registerBtn.textContent = 'Registering...';
    }
    
    try {
        const response = await fetch(`${API_BASE_URL}/auth/register`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                username: username,
                email: email,
                password: password,
                fullName: firstName + ' ' + lastName
            })
        });
        
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.error || 'Registration failed');
        }
        
        showNotification('Registration successful! Please login.', 'success');
        
        setTimeout(() => {
            window.location.href = 'login.html';
        }, 1500);
        
    } catch (error) {
        console.error('Registration error:', error);
        showNotification(error.message || 'Registration failed', 'error');
        
        if (registerBtn) {
            registerBtn.disabled = false;
            registerBtn.textContent = 'Register';
        }
    }
}

// Check authentication
function checkAuth() {
    const isLoggedIn = localStorage.getItem('isLoggedIn');
    const currentPage = window.location.pathname.split('/').pop();
    
    if (currentPage === 'dashboard.html' && isLoggedIn !== 'true') {
        window.location.href = 'login.html';
    }
    
    if (currentPage === 'dashboard.html') {
        const userName = localStorage.getItem('userName') || 'User';
        const userNameEl = document.getElementById('userName');
        if (userNameEl) userNameEl.textContent = userName;
    }
}

// Handle logout
function handleLogout() {
    localStorage.removeItem('isLoggedIn');
    localStorage.removeItem('userName');
    localStorage.removeItem('userId');
    showNotification('Logged out successfully');
    setTimeout(() => {
        window.location.href = 'index.html';
    }, 1000);
}

// ============================================
// INITIALIZATION
// ============================================
document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM loaded - initializing app');
    
    // Check authentication
    checkAuth();
    
    // Initialize dashboard if on dashboard page
    if (document.getElementById('tasksContainer')) {
        fetchTasks();
    }
    
    // ============================================
    // EVENT LISTENERS
    // ============================================
    
    // Login form
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }
    
    // Register form
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        registerForm.addEventListener('submit', handleRegister);
    }
    
    // Add task form
    const addTaskForm = document.getElementById('addTaskForm');
    if (addTaskForm) {
        addTaskForm.addEventListener('submit', addTask);
    }
    
    // Edit task form
    const editTaskForm = document.getElementById('editTaskForm');
    if (editTaskForm) {
        editTaskForm.addEventListener('submit', saveEditTask);
    }
    
    // Logout button
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', handleLogout);
    }
    
    // Menu items
    document.querySelectorAll('.menu-item').forEach(item => {
        item.addEventListener('click', function(e) {
            e.preventDefault();
            const view = this.dataset.view;
            changeView(view, this);
        });
    });
    
    // Search input
    const searchInput = document.getElementById('searchTasks');
    if (searchInput) {
        searchInput.addEventListener('input', debounce(function() {
            renderTasks();
        }, 300));
    }
    
    // Refresh button
    const refreshBtn = document.getElementById('refreshBtn');
    if (refreshBtn) {
        refreshBtn.addEventListener('click', function() {
            fetchTasks();
        });
    }
    
    // Modal close buttons
    document.querySelectorAll('.close, .modal-close').forEach(btn => {
        btn.addEventListener('click', closeModal);
    });
    
    // Close modal when clicking outside
    window.addEventListener('click', function(event) {
        const modal = document.getElementById('editModal');
        if (event.target === modal) {
            closeModal();
        }
    });
});

// Debounce function for search
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Make functions available globally for onclick attributes
window.editTask = editTask;
window.deleteTask = deleteTask;
window.toggleTaskComplete = toggleTaskComplete;
window.handleLogin = handleLogin;
window.handleRegister = handleRegister;
window.handleLogout = handleLogout;
window.closeModal = closeModal;