# TodoMaster - Frontend Application

## Project Overview
This is the frontend for a Todo Management Application developed as part of my internship project. The application allows users to manage their daily tasks efficiently with features like task creation, priority setting, due dates, and task filtering.

## Technologies Used
- **HTML5** - Structure and content
- **CSS3** - Styling and responsive design
- **JavaScript (ES6+)** - Interactive functionality
- **Font Awesome** - Icons
- **Google Fonts** - Typography

## Features Implemented
✅ Responsive landing page
✅ User login and registration forms
✅ Dashboard with task management
✅ Add, edit, delete tasks
✅ Mark tasks as complete/incomplete
✅ Filter tasks by status and priority
✅ Search tasks
✅ Local storage for demo data
✅ Mobile-friendly design

## Project Structure